"""GridFS 文件管理模块：上传、下载、列出文件并校验。"""
import os
from gridfs import GridFS
from audit_log import log_operation

# 默认文件目录（请根据实际情况修改）
GRIDFS_DIR = os.getenv("GRIDFS_DIR", "/final_data/gridfs_files/")

# 文件与 ISBN 对应关系（根据实际 files_manifest.txt 修改）
FILE_MANIFEST = [
    {"filename": "ebook_1.pdf", "cover": "cover_1.png", "isbn": "978-7-1-1", "type": "pdf"},
    {"filename": "ebook_2.pdf", "cover": "cover_2.png", "isbn": "978-7-1-2", "type": "pdf"},
    {"filename": "ebook_3.pdf", "cover": "cover_3.png", "isbn": "978-7-1-3", "type": "pdf"},
]

def upload_all_files(db):
    """上传所有 PDF 和封面图到 GridFS，并将元数据写入 books 集合的 ebook_name 字段。"""
    fs = GridFS(db)
    uploaded = []
    for item in FILE_MANIFEST:
        # 上传 PDF
        pdf_path = os.path.join(GRIDFS_DIR, item["filename"])
        if not os.path.exists(pdf_path):
            print(f"[警告] 文件不存在：{pdf_path}")
            continue
        with open(pdf_path, "rb") as f:
            pdf_id = fs.put(f, filename=item["filename"], metadata={
                "isbn": item["isbn"],
                "file_type": "pdf",
                "original_name": item["filename"]
            })
        # 更新 books 集合中该 ISBN 图书的 ebook_name 字段
        db.books.update_one(
            {"isbn": item["isbn"]},
            {"$set": {"ebook_name": item["filename"]}}
        )
        log_operation(db, "libWriter", "UPLOAD", "gridfs", str(pdf_id), f"上传 PDF: {item['filename']}")
        uploaded.append(item["filename"])

        # 上传封面（同一 ISBN）
        cover_path = os.path.join(GRIDFS_DIR, item["cover"])
        if os.path.exists(cover_path):
            with open(cover_path, "rb") as f:
                cover_id = fs.put(f, filename=item["cover"], metadata={
                    "isbn": item["isbn"],
                    "file_type": "png",
                    "original_name": item["cover"]
                })
            log_operation(db, "libWriter", "UPLOAD", "gridfs", str(cover_id), f"上传封面: {item['cover']}")
            uploaded.append(item["cover"])
        else:
            print(f"[警告] 封面不存在：{cover_path}")
    return uploaded

def list_gridfs_files(db):
    """列出 GridFS 中所有文件及其元数据（文件名、大小、上传时间）。"""
    fs = GridFS(db)
    files = []
    for grid_file in fs.find():
        files.append({
            "filename": grid_file.filename,
            "length": grid_file.length,
            "upload_date": grid_file.upload_date,
            "metadata": grid_file.metadata
        })
    return files

def download_book_by_title(db, title_keyword, save_dir="/tmp"):
    """根据书名关键词查找图书，下载其关联的电子书 PDF，并校验字节数。"""
    book = db.books.find_one({"title": {"$regex": title_keyword, "$options": "i"}})
    if not book:
        print(f"未找到书名包含 '{title_keyword}' 的图书")
        return None
    if "ebook_name" not in book or not book["ebook_name"]:
        print("该图书没有关联电子书")
        return None
    ebook_name = book["ebook_name"]
    fs = GridFS(db)
    grid_file = fs.find_one({"filename": ebook_name})
    if not grid_file:
        print(f"GridFS 中未找到文件 {ebook_name}")
        return None
    # 下载到本地
    save_path = os.path.join(save_dir, ebook_name)
    with open(save_path, "wb") as f:
        grid_file.seek(0)
        while True:
            chunk = grid_file.read(1024 * 1024)
            if not chunk:
                break
            f.write(chunk)
    # 校验字节数
    local_size = os.path.getsize(save_path)
    if local_size == grid_file.length:
        print(f"下载成功：{save_path}，字节数校验一致 ({local_size} 字节)")
        log_operation(db, "libWriter", "EXPORT", "gridfs", str(grid_file._id), f"下载 {ebook_name} 并校验一致")
        return save_path
    else:
        print(f"字节数不一致：本地 {local_size}, GridFS {grid_file.length}")
        log_operation(db, "libWriter", "EXPORT", "gridfs", str(grid_file._id), f"下载 {ebook_name} 校验失败", "FAILED")
        return None
