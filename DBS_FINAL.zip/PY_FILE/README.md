# 智慧图书馆数字资源平台 - 应用程序

本目录包含任务四所开发的 Python 程序，基于 MongoDB 数据库 `library_final` 实现图书、读者、借阅、统计及 GridFS 文件管理功能。

## 环境要求

- Python 3.6+
- `pymongo` 库
- MongoDB 运行中，监听端口 27016（可配置）
- 已创建数据库 `library_final` 及用户 `libWriter`（读写权限）

## 安装依赖

```bash
pip install pymongo
```

## 配置说明

默认配置（可修改 `mongodb_connect.py` 或使用环境变量覆盖）：

| 参数 | 默认值 | 说明 |
|------|--------|------|
| 主机 | `127.0.0.1` | MongoDB 地址 |
| 端口 | `27016` | MongoDB 端口 |
| 数据库 | `library_final` | 业务数据库 |
| 认证用户 | `libWriter` | 默认读写用户 |
| 认证数据库 | `library_final` | 用户所在数据库 |

可通过环境变量 `MONGO_HOST`、`MONGO_PORT`、`MONGO_DB`、`MONGO_USER`、`MONGO_PASSWORD` 等进行覆盖。

## 运行方法

```bash
python main.py
```

程序启动后会提示输入 `libWriter` 用户密码（密码不回显）。连接成功后显示主菜单，按数字选择功能。

## 功能概览

- 图书管理：新增、删除、更新图书；按类别+价格、标签、书名模糊、年份范围查询；查看缺少 tags 的图书；评分排行前10
- 读者管理：新增、删除、更新读者；按学院统计人数；等级分布
- 借阅管理：借阅登记、归还处理、逾期查询
- 统计分析：分类统计、各学院借阅总量前5、月度借阅趋势、热门图书前10（含馆藏位置）、将分类统计结果写入 `category_stats`
- GridFS 文件管理：上传所有电子书和封面、列出文件、按书名下载并校验字节数
- 审计日志：查看最近操作记录（自动记录插入、删除、更新、上传、导出等操作）

## 文件说明

| 文件名 | 作用 |
|--------|------|
| `main.py` | 主程序入口，菜单交互 |
| `mongodb_connect.py` | 统一数据库连接模块 |
| `audit_log.py` | 操作日志写入模块 |
| `book_manager.py` | 图书管理相关函数 |
| `reader_manager.py` | 读者管理相关函数 |
| `borrow_manager.py` | 借阅管理相关函数 |
| `stat_manager.py` | 统计分析与聚合 |
| `gridfs_manager.py` | GridFS 文件上传、下载、列表 |

## 注意事项

- `gridfs_manager.py` 中的 `GRIDFS_DIR` 和 `FILE_MANIFEST` 需根据实际电子书文件路径和 ISBN 对应关系修改。
- 归还图书时需要提供借阅记录的 `_id`（ObjectId），可从借阅登记后返回的 ID 获取。
- 时间序列集合 `borrow_logs` 的过期时间已在建库时设置（2年或5年），本程序不会自动修改。
