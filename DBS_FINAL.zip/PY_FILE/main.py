"""主程序：菜单式交互，整合所有模块。"""
import sys
from bson.objectid import ObjectId
from mongodb_connect import connect
import book_manager as bm
import reader_manager as rm
import borrow_manager as brm
import stat_manager as sm
import gridfs_manager as gm
from audit_log import log_operation

def print_menu():
    print("\n" + "=" * 50)
    print("智慧图书馆数字资源平台 - 主菜单")
    print("=" * 50)
    print("1. 图书管理")
    print("2. 读者管理")
    print("3. 借阅管理")
    print("4. 统计分析")
    print("5. GridFS 文件管理")
    print("6. 查看最近的审计日志")
    print("0. 退出")
    print("-" * 50)

def book_submenu(db):
    print("\n-- 图书管理 --")
    print("1. 新增图书")
    print("2. 删除图书（按ISBN）")
    print("3. 更新图书")
    print("4. 按类别+价格区间查询")
    print("5. 按标签多选查询")
    print("6. 书名模糊查询")
    print("7. 出版年份范围查询")
    print("8. 缺少tags字段图书")
    print("9. 评分排序前10")
    print("0. 返回")
    choice = input("请选择: ").strip()
    if choice == "1":
        isbn = input("ISBN: ")
        title = input("书名: ")
        author = input("作者: ")
        publisher = input("出版社: ")
        category = input("类别: ")
        price = float(input("定价: "))
        stock = int(input("库存: "))
        rating = float(input("评分: "))
        tags = input("标签（逗号分隔，可空）: ").split(",")
        tags = [t.strip() for t in tags if t.strip()]
        publish_date = input("出版日期(YYYY-MM-DD): ")
        from datetime import datetime
        pd = datetime.strptime(publish_date, "%Y-%m-%d")
        location = {
            "floor": input("楼层区域: "),
            "shelf": input("架位号: "),
            "copies": int(input("复本数: "))
        }
        book_data = {
            "isbn": isbn, "title": title, "author": author, "publisher": publisher,
            "category": category, "price": price, "stock": stock, "rating": rating,
            "tags": tags, "publish_date": pd, "borrow_count": 0, "location": location
        }
        bm.insert_book(db, book_data)
        print("已插入图书")
    elif choice == "2":
        isbn = input("要删除的ISBN: ")
        count = bm.delete_book_by_isbn(db, isbn)
        print(f"删除了 {count} 本图书")
    elif choice == "3":
        isbn = input("要更新的ISBN: ")
        field = input("要更新的字段（如 price, stock, rating）: ")
        value = input("新值: ")
        try:
            value = float(value) if "." in value else int(value)
        except ValueError:
            pass
        count = bm.update_book(db, isbn, {field: value})
        print(f"更新了 {count} 条记录")
    elif choice == "4":
        category = input("类别: ")
        min_price = float(input("最低价格: "))
        max_price = float(input("最高价格: "))
        docs = bm.search_by_category_price(db, category, min_price, max_price)
        for doc in docs:
            print(doc)
    elif choice == "5":
        tags = input("标签（逗号分隔，至少两个）: ").split(",")
        tags = [t.strip() for t in tags if t.strip()]
        docs = bm.search_by_tags_all(db, tags)
        for doc in docs:
            print(doc)
    elif choice == "6":
        keyword = input("书名关键词: ")
        docs = bm.search_by_title_regex(db, keyword)
        for doc in docs:
            print(doc)
    elif choice == "7":
        start_year = int(input("起始年份: "))
        end_year = int(input("结束年份: "))
        docs = bm.search_by_publish_year_range(db, start_year, end_year)
        for doc in docs:
            print(doc)
    elif choice == "8":
        docs = bm.search_missing_tags(db)
        for doc in docs:
            print(doc)
    elif choice == "9":
        docs = bm.top_rated_books(db, 10)
        for doc in docs:
            print(doc)
    elif choice == "0":
        return
    else:
        print("无效选择")

def reader_submenu(db):
    print("\n-- 读者管理 --")
    print("1. 新增读者")
    print("2. 删除读者")
    print("3. 更新读者")
    print("4. 按学院统计人数")
    print("5. 等级分布")
    print("0. 返回")
    choice = input("请选择: ").strip()
    if choice == "1":
        card_no = input("借阅证号: ")
        name = input("姓名: ")
        college = input("学院: ")
        email = input("邮箱（可空）: ") or None
        phone = input("电话: ")
        level = input("等级（普通/高级/教师）: ")
        register_date = input("注册日期(YYYY-MM-DD): ")
        from datetime import datetime
        rd = datetime.strptime(register_date, "%Y-%m-%d")
        fav = input("偏好类别（逗号分隔，可空）: ").split(",")
        fav = [f.strip() for f in fav if f.strip()] or []
        reader_data = {
            "card_no": card_no, "name": name, "college": college, "email": email,
            "phone": phone, "level": level, "register_date": rd, "fav_categories": fav
        }
        rm.insert_reader(db, reader_data)
        print("已插入读者")
    elif choice == "2":
        card_no = input("要删除的借阅证号: ")
        count = rm.delete_reader_by_card(db, card_no)
        print(f"删除了 {count} 名读者")
    elif choice == "3":
        card_no = input("要更新的借阅证号: ")
        field = input("要更新的字段: ")
        value = input("新值: ")
        count = rm.update_reader(db, card_no, {field: value})
        print(f"更新了 {count} 条记录")
    elif choice == "4":
        result = rm.count_by_college(db)
        for item in result:
            print(f"{item['_id']}: {item['count']} 人")
    elif choice == "5":
        result = rm.level_distribution(db)
        for item in result:
            print(f"{item['_id']}: {item['count']} 人")
    elif choice == "0":
        return
    else:
        print("无效选择")

def borrow_submenu(db):
    print("\n-- 借阅管理 --")
    print("1. 借阅登记")
    print("2. 归还处理")
    print("3. 逾期查询")
    print("0. 返回")
    choice = input("请选择: ").strip()
    if choice == "1":
        reader_card = input("借阅证号: ")
        book_isbn = input("图书ISBN: ")
        borrow_id = brm.borrow_book(db, reader_card, book_isbn)
        print(f"借阅登记成功，记录ID: {borrow_id}")
    elif choice == "2":
        borrow_id = input("借阅记录ID: ")
        return_date = input("归还日期(YYYY-MM-DD，默认今天): ").strip()
        if return_date:
            from datetime import datetime
            rd = datetime.strptime(return_date, "%Y-%m-%d")
        else:
            rd = None
        count = brm.return_book(db, borrow_id, rd)
        print(f"更新了 {count} 条记录")
    elif choice == "3":
        docs = brm.overdue_books(db)
        for doc in docs:
            print(doc)
    elif choice == "0":
        return
    else:
        print("无效选择")

def stat_submenu(db):
    print("\n-- 统计分析 --")
    print("1. 分类统计（藏书量、均价、均分）")
    print("2. 学院借阅总量前5")
    print("3. 月度借阅趋势")
    print("4. 热门图书前10（含位置）")
    print("5. 将分类统计写入 category_stats 集合")
    print("0. 返回")
    choice = input("请选择: ").strip()
    if choice == "1":
        result = sm.category_stats(db)
        for item in result:
            print(item)
    elif choice == "2":
        result = sm.college_borrow_top5(db)
        for item in result:
            print(item)
    elif choice == "3":
        result = sm.monthly_trend(db)
        for item in result:
            print(item)
    elif choice == "4":
        result = sm.top_borrowed_books_with_location(db, 10)
        for item in result:
            print(item)
    elif choice == "5":
        sm.stats_to_collection(db)
        print("统计结果已写入 category_stats")
    elif choice == "0":
        return
    else:
        print("无效选择")

def gridfs_submenu(db):
    print("\n-- GridFS 文件管理 --")
    print("1. 上传所有电子书和封面")
    print("2. 列出 GridFS 文件")
    print("3. 按书名下载电子书并校验")
    print("0. 返回")
    choice = input("请选择: ").strip()
    if choice == "1":
        uploaded = gm.upload_all_files(db)
        print(f"上传完成，共 {len(uploaded)} 个文件")
    elif choice == "2":
        files = gm.list_gridfs_files(db)
        for f in files:
            print(f"文件名: {f['filename']}, 大小: {f['length']}, 上传时间: {f['upload_date']}")
    elif choice == "3":
        title_keyword = input("书名关键词: ")
        save_path = gm.download_book_by_title(db, title_keyword)
        if save_path:
            print(f"下载到: {save_path}")
    elif choice == "0":
        return
    else:
        print("无效选择")

def show_recent_logs(db, limit=10):
    """查看最近的审计日志。"""
    logs = list(db.audit_logs.find().sort("ts", -1).limit(limit))
    for log in logs:
        print(f"{log['ts']} | {log['operator']} | {log['action']} | {log['target_collection']} | {log.get('detail','')}")

def main():
    client, db = connect()
    print(f"已连接数据库: {db.name}")
    while True:
        print_menu()
        choice = input("请选择: ").strip()
        if choice == "1":
            book_submenu(db)
        elif choice == "2":
            reader_submenu(db)
        elif choice == "3":
            borrow_submenu(db)
        elif choice == "4":
            stat_submenu(db)
        elif choice == "5":
            gridfs_submenu(db)
        elif choice == "6":
            show_recent_logs(db)
        elif choice == "0":
            print("感谢使用，再见！")
            client.close()
            sys.exit(0)
        else:
            print("无效选择，请重新输入")

if __name__ == "__main__":
    main()
