"""操作日志模块：记录平台关键操作到 audit_logs 集合。"""
from datetime import datetime

def log_operation(db, operator, action, target_collection, target_id=None, detail=None, result="SUCCESS"):
    """写入操作日志。"""
    try:
        db.audit_logs.insert_one({
            "ts": datetime.now(),
            "operator": operator,
            "action": action,
            "target_collection": target_collection,
            "target_id": target_id,
            "detail": detail,
            "result": result
        })
    except Exception as e:
        print(f"[警告] 写入操作日志失败：{e}")
