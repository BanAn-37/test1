"""借阅管理模块：借阅登记、归还处理、逾期查询。"""
from datetime import datetime, timedelta
from bson.objectid import ObjectId
from audit_log import log_operation

OPERATOR = "libWriter"

def borrow_book(db, reader_card, book_isbn):
    """登记借阅：插入一条借出记录，状态为“借出”，自动计算时长（可暂时设为0或借阅时长后续更新）。"""
    borrow_date = datetime.now()
    doc = {
        "borrow_date": borrow_date,
        "reader_card": reader_card,
        "book_isbn": book_isbn,
        "status": "借出",
        "duration_days": 0
    }
    result = db.borrow_logs.insert_one(doc)
    log_operation(db, OPERATOR, "INSERT", "borrow_logs", str(result.inserted_id), f"借阅登记：{reader_card} 借 {book_isbn}")
    return result.inserted_id

def return_book(db, borrow_id, return_date=None):
    """归还处理：更新状态为“已归还”，设置归还日期，计算时长。"""
    # 确保 borrow_id 是 ObjectId
    if isinstance(borrow_id, str):
        borrow_id = ObjectId(borrow_id)
    if return_date is None:
        return_date = datetime.now()
    doc = db.borrow_logs.find_one({"_id": borrow_id})
    if not doc:
        log_operation(db, OPERATOR, "UPDATE", "borrow_logs", str(borrow_id), "未找到借阅记录", "FAILED")
        return 0
    duration = (return_date - doc["borrow_date"]).days
    result = db.borrow_logs.update_one(
        {"_id": borrow_id},
        {"$set": {"status": "已归还", "return_date": return_date, "duration_days": duration}}
    )
    if result.modified_count > 0:
        log_operation(db, OPERATOR, "UPDATE", "borrow_logs", str(borrow_id), f"归还图书，时长 {duration} 天")
    return result.modified_count

def overdue_books(db, current_date=None):
    """查询逾期图书（假设借阅期限为30天）。"""
    if current_date is None:
        current_date = datetime.now()
    cutoff = current_date - timedelta(days=30)
    return list(db.borrow_logs.find({
        "status": "借出",
        "borrow_date": {"$lt": cutoff}
    }))
