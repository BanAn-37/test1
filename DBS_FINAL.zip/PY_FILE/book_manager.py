"""图书管理模块：提供图书增删改查、条件检索、评分排行。"""
from datetime import datetime
from audit_log import log_operation

OPERATOR = "libWriter"

def insert_book(db, book_data):
    """插入一本新书。"""
    try:
        result = db.books.insert_one(book_data)
        log_operation(db, OPERATOR, "INSERT", "books", str(result.inserted_id), f"新增图书：{book_data.get('title','')}")
        return result.inserted_id
    except Exception as e:
        log_operation(db, OPERATOR, "INSERT", "books", None, str(e), "FAILED")
        raise

def delete_book_by_isbn(db, isbn):
    """按 ISBN 删除图书。"""
    result = db.books.delete_one({"isbn": isbn})
    if result.deleted_count > 0:
        log_operation(db, OPERATOR, "DELETE", "books", isbn, f"删除图书 ISBN={isbn}")
    else:
        log_operation(db, OPERATOR, "DELETE", "books", isbn, "未找到图书", "FAILED")
    return result.deleted_count

def update_book(db, isbn, update_fields):
    """更新指定图书的部分字段（使用 $set）。"""
    result = db.books.update_one({"isbn": isbn}, {"$set": update_fields})
    if result.modified_count > 0:
        log_operation(db, OPERATOR, "UPDATE", "books", isbn, f"更新字段：{update_fields}")
    return result.modified_count

def search_by_category_price(db, category, min_price, max_price):
    """按类别与价格区间组合筛选。"""
    return db.books.find(
        {"category": category, "price": {"$gte": min_price, "$lte": max_price}}
    )

def search_by_tags_all(db, tags):
    """按标签多选匹配（同时含多个指定标签）。"""
    return db.books.find({"tags": {"$all": tags}})

def search_by_title_regex(db, keyword):
    """按书名模糊检索。"""
    return db.books.find({"title": {"$regex": keyword, "$options": "i"}})

def search_by_publish_year_range(db, start_year, end_year):
    """按出版年份范围检索。"""
    start = datetime(start_year, 1, 1)
    end = datetime(end_year + 1, 1, 1)
    return db.books.find({"publish_date": {"$gte": start, "$lt": end}})

def search_missing_tags(db):
    """查询缺少 tags 字段的图书。"""
    return db.books.find({"tags": {"$exists": False}})

def top_rated_books(db, limit=10):
    """按评分排序取前 N，仅返回书名、作者、评分。"""
    return list(db.books.find(
        {},
        {"_id": 0, "title": 1, "author": 1, "rating": 1}
    ).sort("rating", -1).limit(limit))

def export_books_by_query(db, query, output_collection):
    """导出查询结果到新集合（用于测试导出功能，并记录日志）。"""
    docs = list(db.books.find(query))
    if docs:
        db[output_collection].drop()
        db[output_collection].insert_many(docs)
    log_operation(db, OPERATOR, "EXPORT", "books", None, f"导出 {len(docs)} 条记录到 {output_collection}")
    return len(docs)
