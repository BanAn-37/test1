"""读者管理模块：读者信息管理、学院统计、等级分布。"""
from audit_log import log_operation

OPERATOR = "libWriter"

def insert_reader(db, reader_data):
    """插入新读者。"""
    result = db.readers.insert_one(reader_data)
    log_operation(db, OPERATOR, "INSERT", "readers", str(result.inserted_id), f"新增读者：{reader_data.get('name','')}")
    return result.inserted_id

def delete_reader_by_card(db, card_no):
    """按借阅证号删除读者。"""
    result = db.readers.delete_one({"card_no": card_no})
    if result.deleted_count > 0:
        log_operation(db, OPERATOR, "DELETE", "readers", card_no, f"删除读者 {card_no}")
    return result.deleted_count

def update_reader(db, card_no, update_fields):
    """更新读者信息。"""
    result = db.readers.update_one({"card_no": card_no}, {"$set": update_fields})
    if result.modified_count > 0:
        log_operation(db, OPERATOR, "UPDATE", "readers", card_no, f"更新字段：{update_fields}")
    return result.modified_count

def count_by_college(db):
    """按学院统计读者数量。"""
    return list(db.readers.aggregate([
        {"$group": {"_id": "$college", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}}
    ]))

def level_distribution(db):
    """按借阅等级统计读者数量。"""
    return list(db.readers.aggregate([
        {"$group": {"_id": "$level", "count": {"$sum": 1}}}
    ]))
