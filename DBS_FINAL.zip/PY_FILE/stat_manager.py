"""统计分析模块：提供分类统计、借阅趋势、热门排行等聚合。"""
from audit_log import log_operation

def category_stats(db):
    """按类别统计图书数量、平均价格、平均评分。"""
    return list(db.books.aggregate([
        {"$group": {
            "_id": "$category",
            "count": {"$sum": 1},
            "avg_price": {"$avg": "$price"},
            "avg_rating": {"$avg": "$rating"}
        }},
        {"$sort": {"count": -1}}
    ]))

def college_borrow_top5(db):
    """统计各学院借阅总量前5名（按读者所属学院汇总借阅次数）。"""
    pipeline = [
        {"$group": {
            "_id": "$reader_card",
            "borrow_count": {"$sum": 1}
        }},
        {"$lookup": {
            "from": "readers",
            "localField": "_id",
            "foreignField": "card_no",
            "as": "reader_info"
        }},
        {"$unwind": "$reader_info"},
        {"$group": {
            "_id": "$reader_info.college",
            "total_borrow": {"$sum": "$borrow_count"}
        }},
        {"$sort": {"total_borrow": -1}},
        {"$limit": 5}
    ]
    return list(db.borrow_logs.aggregate(pipeline))

def monthly_trend(db):
    """按年月统计借阅趋势，格式化为 YYYY-MM。"""
    return list(db.borrow_logs.aggregate([
        {"$group": {
            "_id": {"$dateToString": {"format": "%Y-%m", "date": "$borrow_date"}},
            "count": {"$sum": 1}
        }},
        {"$sort": {"_id": 1}}
    ]))

def top_borrowed_books_with_location(db, limit=10):
    """借阅最多的图书（前 N 本），并关联馆藏位置。"""
    return list(db.borrow_logs.aggregate([
        {"$group": {
            "_id": "$book_isbn",
            "borrow_count": {"$sum": 1}
        }},
        {"$sort": {"borrow_count": -1}},
        {"$limit": limit},
        {"$lookup": {
            "from": "books",
            "localField": "_id",
            "foreignField": "isbn",
            "as": "book_info"
        }},
        {"$unwind": "$book_info"},
        {"$project": {
            "_id": 0,
            "isbn": "$_id",
            "title": "$book_info.title",
            "location": "$book_info.location",
            "borrow_count": 1
        }}
    ]))

def stats_to_collection(db, output_collection="category_stats"):
    """将分类统计结果写入新集合（使用 $merge）。"""
    db.books.aggregate([
        {"$group": {
            "_id": "$category",
            "count": {"$sum": 1},
            "avg_price": {"$avg": "$price"},
            "avg_rating": {"$avg": "$rating"}
        }},
        {"$merge": {
            "into": output_collection,
            "on": "_id",
            "whenMatched": "replace",
            "whenNotMatched": "insert"
        }}
    ])
    log_operation(db, "libWriter", "EXPORT", "books", None, f"统计结果写入 {output_collection}")
