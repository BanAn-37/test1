# MongoDB 图书情报检索与统计平台：逐步实训指南

> 与上传的三份配套 TXT 数据一并打包。只假设你的 MongoDB 服务已正常运行、可连接。不需要重新安装 MongoDB。
> 初始样本：books 20、readers 16、borrow_logs 原始 66（其中已归还39、借出14、逾期13）。
> 建议使用 Windows PowerShell + mongosh + Python 3.9+ + MongoDB Compass。脚本最好在 MongoDB 7.0+/8.0+ 上执行，`$topN` 要求 MongoDB 5.2+。

## 1. 解压、目录与终端

解压整个 `library_platform` 文件夹，建议放在没有特殊权限限制的路径，如 `D:\Projects\library_platform`。

在 PyCharm 中点 File -> Open，选中 `library_platform`，打开 Terminal。

重要：以下 `mongosh "mongodb://..." --file ...`、`python ...`、`pip ...` 是在 **Windows PowerShell/CMD/PyCharm Terminal** 执行，
不是在 `mongosh>` 交互提示符内输入。

```powershell
cd D:\Projects\library_platform
python --version
mongosh --version
mongosh "mongodb://127.0.0.1:27017" --eval "db.adminCommand({ping:1})"
```

如果服务启用认证，请在环境变量 `MONGO_URI` 中设置可访问 library 的 URI，确保 `mongosh` 命令也使用相同认证。
避免把密码直接写入脚本或提交到报告中。用户密码含 `@/#:?` 等特殊字符需做 URI 编码。
可以使用 `mongosh -u 账户 --authenticationDatabase library -p` 的交互方式，直接输入密码。

## 2. 创建数据库和特殊集合（任务二 ST-2.1、ST-2.2）

```powershell
mongosh "mongodb://127.0.0.1:27017" --file scripts/01_setup.js
```

该脚本执行：
- 创建 library 数据库。
- 创建 books、readers、category_stats 普通集合。
- 创建 borrow_logs 时间序列集合，`timeField=borrow_date`, `granularity=hours`, `expireAfterSeconds=63072000`。
- 创建 book_logs 固定集合，1MB、最多1000条。
- 创建 book_in_stock 视图，仅显示 stock>0 图书。
- 增加 borrow_archive 普通历史归档集合，使已超过2年 TTL 的配套记录仍然能被完整统计，且可修改归还状态。

⚠️ 时间序列过期风险：配套借阅记录涵盖2023—2025年，当前2026年部分记录已满足过期条件，
故 `borrow_logs` 导入时可能暂时显示66条，之后被 MongoDB 后台TTL清理；不要将其持续维持66条作为硬性验收条件。
使用 `borrow_archive` 核对初始历史借阅66条。此次额外建归档集合是为了保留任务书提供的历史数据。
若任务书要求所有历史数据必须长期保留在 `borrow_logs` 本身，就与其“两年TTL”要求存在冲突，须与教师沟通。

数据库已有集合时脚本会复用并保护现有集合，而非直接删除覆盖。
如果发现 `borrow_logs` 原先是普通集合，脚本会停止，避免悄悄换类型。
可以使用 `mongosh "mongodb://127.0.0.1:27017"` 后执行：
```javascript
use library
db.getCollectionInfos({name:"borrow_logs"})
db.getCollectionInfos({name:"book_logs"})
db.getCollectionInfos({name:"book_in_stock"})
```

## 3. 导入真实配套数据（任务二 ST-2.3）

先安装 Python 驱动：
```powershell
python -m pip install -r requirements.txt
```
然后执行：
```powershell
python scripts/import_data.py
```

该程序会：
1. 用 `bson.json_util.loads` 直接识别 Extended JSON 的 `$date`，确保日期入库是 BSON Date。
2. 校验 20 条 ISBN 无重复、16 条借阅证无重复、借阅的 ISBN 和证号均可关联。
3. 对图书先执行 `insert_one` 插入第一条，再用 `insert_many` 插入其余19条。
4. 对读者用 `insert_many` 导入16条。
5. 将66条借阅记录完整导入 `borrow_archive`，并写入时间序列 `borrow_logs`。
6. 打印各集合的实际数量。

默认导入器是“一次性导入”：当任一核心集合非空时会主动停止，避免重复导入和主键冲突。
如需从头重做，请先备份，然后自行确认实验库中的数据后再清理/重建，不要在生产库执行 `dropDatabase()`。

对于日期字段 `borrow_date` / `publish_date`：
```javascript
db.borrow_archive.findOne().borrow_date instanceof Date  // true
db.books.findOne().publish_date instanceof Date           // true
```

## 4. 查询功能 Q1-Q16（任务三 ST-3）

务必 **先运行查询并截图**，再执行会修改数据的脚本。

```powershell
mongosh "mongodb://127.0.0.1:27017" --file scripts/02_queries.js
```

本数据集在未修改时的预期结果：
| 编号 | 条数 / 结果 |
|---|---|
| Q1 价格>80 | 7 |
| Q2 库存<10 | 8 |
| Q3 ISBN=9787115428028 | 1 |
| Q4 email 为 null | 3 |
| Q5 非“人民邮电出版社” | 16 |
| Q6 计算机/经济管理 | 10 |
| Q7 计算机且评分>4 | 7 |
| Q8 评分<3.5 或库存0 | 1 |
| Q9 标题含Python | 1 |
| Q10 标签同时含“编程”和“入门” | 1 |
| Q11 恰有3个标签 | 12 |
| Q12 有tags字段 | 17 |
| Q13 `_id` 为字符串 | 1 |
| Q14 前5名 | 5 |
| Q15 全部书籍投影 | 20 |
| Q16 distinct 类别 | 5种 |

Q16 类别：计算机、文学、经济管理、数学、外语。

## 5. 任务四聚合与索引（推荐修改数据之前执行）

```powershell
mongosh "mongodb://127.0.0.1:27017" --file scripts/04_aggregations.js
mongosh "mongodb://127.0.0.1:27017" --file scripts/05_indexes.js
```

`scripts/04_aggregations.js` 包括全部 A1～A9：
- A1 按类别计数/平均评分/库存极值
- A2 按出版社计数，并用 `$topN` 取数量前5
- A3 `$sortByCount` 最大类别
- A4 评分最高三本图书
- A5 单价×借阅次数，`$round` 保留两位（按题目称销售额，严格讲这是估算指标）
- A6 使用 `$year` + `$dateToString` 年度趋势（基于 borrow_archive 的66条历史）
- A7 读者借阅次数前五
- A8 `$lookup` 关联读者，按学院统计借阅量
- A9 `$merge` 保存 A1 结果到 category_stats

初始年度记录：2023年20、2024年28、2025年18；共计66。
初始类别：计算机7、文学5、经济管理3、数学3、外语2；A9 预计写入5个分类统计文档。

`scripts/05_indexes.js` 包括 I1～I5；会插入一条重复ISBN做验证，正确结果为 `E11000`，记录不会真正进入集合。
用 `hint({$natural:1})` 强制集合扫描，与 `hint("idx_category_price")` 使用复合索引的 explain 比较。
由于只有20条图书，时间毫秒指标可能难以反映差异，报告中重点比较 `totalDocsExamined` / `totalKeysExamined`。

## 6. 更新、删除（任务三 U1～U4，D1～D3）

所有更改会使 Q1～Q16/聚合统计计数随之改变，**建议放在上述步骤之后**。先制作备份：

```powershell
mongodump --uri="mongodb://127.0.0.1:27017" --db library --out backup
```

上述命令要求另行安装 MongoDB Database Tools。
也可以先用 Compass 将数据导出 JSON 留档。

首次执行只预览、不修改：
```powershell
mongosh "mongodb://127.0.0.1:27017" --file scripts/03_changes.js
```
代码顶部有两个明确的开关：
```javascript
const RUN_MUTATIONS = false;
const RUN_TIMESERIES_DELETES = false;
```
确认截图已完成、已备份后，将 `RUN_MUTATIONS` 改成 `true`，即可执行：
- U1 `updateOne` + `$inc` 库存减5
- U2 `updateMany` + `$mul` 外语类价格9折
- U3 `updateOne` + `$currentDate` 自动记录更新日期
- U4 `updateOne` + `$unset` 删除指定图书 tags
- D3 `replaceOne` 完整替换指定读者且保留 `_id`

D1、D2 是删除时间序列数据，必须额外将 `RUN_TIMESERIES_DELETES` 设为 `true`；
此操作要求支持非metaField删除的 MongoDB版本/相应功能兼容版本（建议7.0+）。
当前 D2 条件是 `status="逾期" 且 return_date 不存在`。
配套数据的13条“逾期”记录都已填 `return_date`，故初始归档上 D2 预览结果为0。
运行过程中时间序列又可能受TTL影响，D1的目标数量也会变动。
请在报告中真实记录 matched/deleted 数，不要编造结果。

注意 D1/D2仅用于任务书的CRUD方法实验；时间序列集合的删除不会同步修改
`borrow_archive`，它是独立存储的实验原始历史数据。业务应用不要靠随意删除流水来处理归还。

## 7. PyCharm 中运行 Python 菜单程序（任务五）

六个要求的模块：
```
mongodb_connect.py
book_manager.py
reader_manager.py
borrow_manager.py
stat_manager.py
main.py
```

在项目根目录运行：
```powershell
python main.py
```

推荐功能演示顺序：
1. 按 `1` 搜索关键词 `Python`；按 `2` 查 ISBN `9787115428028`。
2. 按 `6` 查询评分前5；按 `9` 查询学院读者统计；按 `10` 查询读者等级。
3. 按 `15` 分类统计、`16` 年度借阅、`17` 热门图书排行、`18` 活跃读者排行。
4. 按 `19` 将统计结果落库；到 Compass 检查 category_stats。
5. 按 `11` 办理借阅：读者 `R20240001`，ISBN `9787115428028`（原始库存15本）。
   记录返回的 **借阅记录ID**，新增记录写入 borrow_archive，时间序列记借阅事件。
6. 按 `12` 输入上一步返回的借阅ID办理归还；原库存自动+1，并向时间序列追加归还事件。
7. 按 `13` 查看历史借阅；按 `14` 查看超过30天仍未归还的真实逾期记录。
8. 按 `3` 新增测试图书、`4` 修改库存、`5` 删除测试图书；录入/删除会打印受影响条数。
9. 按 `0` 退出，程序会关闭 MongoDB 连接。

设计说明：时间序列字段并不适合直接执行 `updateMany({"_id":...},{"$set":{"status":"已归还"}})`。
Python 程序真正修改的是辅助普通集合 `borrow_archive`，时间序列集合只追加借阅/归还事件。
对历史统计采用 archive，避免 TTL 截断数据。当前 Python 项目使用简单单机演示级操作与尽力回滚，不具备跨多个集合的事务原子性，不能直接当作生产借阅系统部署。

## 8. 账户权限实验 S1～S3（建议最后做）

> 这一步可能改变已有服务的登录方式；请确保你拥有 MongoDB 配置文件/管理员权限和服务重启能力。
> 如 MongoDB 已启用访问控制，用现有管理员运行建用户命令，跳过配置修改。

如果当前 MongoDB 未开启认证，**先创建管理员**，不要先创建普通业务账号：
```javascript
// 在 mongosh 的交互终端运行
use admin
db.createUser({
  user:"libraryAdmin",
  pwd:passwordPrompt(),
  roles:[{role:"root",db:"admin"}]
})
```
然后使用管理员/现有管理账户运行（如未启用认证，先创建admin后也能运行）：
```powershell
mongosh "mongodb://127.0.0.1:27017" --file scripts/07_users.js
```
将提示交互输入 `libReader` 和 `libWriter` 的密码，`passwordPrompt()` 不会在代码中保存明文。

用服务的实际 `mongod.cfg` 或 `mongod.conf` 启用访问控制，配置：
```yaml
security:
  authorization: enabled
```
注意：应合并到原有配置文件，不能仅为了此项覆盖其他服务设置。
按你已有的服务方式重启 MongoDB，确保管理员能重新登录后再做验证。

只读账号验证（系统终端）：
```powershell
mongosh --host 127.0.0.1 --port 27017 -u libReader --authenticationDatabase library -p
```
进入后：
```javascript
use library
db.books.findOne()                                  // 应成功
db.books.insertOne({isbn:"PERM-TEST",title:"权限测试"}) // 应报 not authorized
```

读写账号验证（系统终端）：
```powershell
mongosh --host 127.0.0.1 --port 27017 -u libWriter --authenticationDatabase library -p
```
进入后：
```javascript
use library
db.books.findOne()
db.books.insertOne({isbn:"PERM-TEST",title:"权限测试"})
db.books.deleteOne({isbn:"PERM-TEST"}) // 清理测试数据
```

此后运行 `python main.py` 时若遇到认证错误，需设置 `MONGO_URI`：
```powershell
# 把 YOUR_ENCODED_PASSWORD 替换为自己URL编码后的密码；不要上传/提交密码
$env:MONGO_URI="mongodb://libWriter:YOUR_ENCODED_PASSWORD@127.0.0.1:27017/library?authSource=library"
python main.py
```
环境变量只在当前 PowerShell 会话中有效。使用其它终端可用该终端自己的环境变量语法。
若担心密码进入终端历史，建议在 PyCharm Run Configuration 中设置环境变量，或通过安全方式输入。

## 9. Compass 图形化核验（任务六）

打开 MongoDB Compass，连接与上述 Python 代码同一个服务器、同一个 `library` 数据库。
检查：
- `borrow_logs` 类型为 Time Series；
- `book_logs` 类型为 Capped；
- `book_in_stock` 为 View；
- `books` 20条、`readers` 16条、`borrow_archive` 66条（均未修改时）；
- `borrow_logs` 可能少于66条（TTL造成，属预期）；
- Compass Filter 依次验证 Q1、Q2、Q7、Q14；
- Aggregations 验证 A1；`category_stats` 核查 A9；
- 导出 books 和 category_stats 的 JSON 数据。

命令检查：
```powershell
mongosh "mongodb://127.0.0.1:27017" --file scripts/08_check.js
```

## 10. 交付材料与截图清单

建议建立提交目录：
```
实训提交/
  01_数据文件或数据库备份/
  02_Python源代码/  (上述6文件)
  03_MongoDB脚本/   (scripts内.js脚本)
  04_技术文档/      (3-4页)
  05_截图/
```
必须截图：启动连接结果；数据库集合/特殊集合配置；导入条数；
16项检索的关键命令与条数；U1-U4/D1-D3结果及D2预览；
A1-A9结果；索引清单和explain；只读账号读成功/写拒绝；
Python菜单+借还操作+统计；Compass验证与导出文件。

另附 `技术报告模板.md`、`查询结果核对表.md` 可按真实环境补充。
不要把服务器管理员密码、业务密码、密码URI或含密码的环境变量截图写进报告。

## 11. 适用边界

- 我已离线检查 TXT 文件内容与代码语法；未连接你的本地 MongoDB 实例。
- 真正的 TTL 后计数、权限错误、索引 explain 耗时以你机器的执行结果为准。
- 不建议在重要数据库上运行任何实验删除指令；如本机已有同名 `library` 数据库，请先备份。
