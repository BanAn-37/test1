"""统一数据库连接入口；可通过环境变量 MONGO_URI 配置认证。"""
import os
from pymongo import MongoClient

DATABASE_NAME = "library"
DEFAULT_URI = "mongodb://127.0.0.1:27017"

def connect():
    client = MongoClient(
        os.getenv("MONGO_URI", DEFAULT_URI),
        serverSelectionTimeoutMS=5000,
        tz_aware=True
    )
    try:
        client.admin.command("ping")
        return client, client[DATABASE_NAME]
    except Exception:
        client.close()
        raise
