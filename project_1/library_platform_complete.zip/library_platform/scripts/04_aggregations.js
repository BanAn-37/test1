// A1～A9：完整聚合；借阅历史来自不会被 TTL 清掉的 borrow_archive。
const d = db.getSiblingDB("library");
function show(id, title, collection, pipe) {
  print("\n" + id + " " + title);
  const rows=d.getCollection(collection).aggregate(pipe).toArray();
  print("结果行数：" + rows.length); printjson(rows);
  return rows;
}
const A1=[
  {$group:{_id:"$category",book_count:{$sum:1},
           avg_rating:{$avg:"$rating"},
           min_stock:{$min:"$stock"},max_stock:{$max:"$stock"}}},
  {$sort:{book_count:-1,_id:1}}
];
show("A1","各类别数量、平均评分、最高最低库存","books",A1);
show("A2","出版社数量排行榜（$topN；要求MongoDB 5.2+）","books",[
  {$group:{_id:"$publisher",count:{$sum:1}}},
  {$group:{_id:null,top_five:{$topN:{
    n:5,sortBy:{count:-1,_id:1},
    output:{publisher:"$_id",count:"$count"}}}}},
  {$project:{_id:0,top_five:1}}
]);
show("A3","文档最多的类别","books",[
  {$sortByCount:"$category"},{$limit:1}
]);
show("A4","评分最高三本书及借阅次数","books",[
  {$sort:{rating:-1,_id:1}},{$limit:3},
  {$project:{_id:0,title:1,rating:1,borrow_count:1}}
]);
show("A5","单价×借阅次数（按题目命名为销售额）","books",[
  {$project:{_id:0,title:1,price:1,borrow_count:1,
    total_amount:{$round:[{$multiply:["$price","$borrow_count"]},2]}}},
  {$sort:{total_amount:-1}}
]);
show("A6","借阅年份及年月格式演示；用$year与$dateToString","borrow_archive",[
  {$project:{
    year:{$year:{date:"$borrow_date",timezone:"Asia/Shanghai"}},
    year_label:{$dateToString:{
      format:"%Y年",date:"$borrow_date",timezone:"Asia/Shanghai"}}}},
  {$group:{_id:{year:"$year",year_label:"$year_label"},
           borrow_count:{$sum:1}}},
  {$sort:{"_id.year":1}},
  {$project:{_id:0,year:"$_id.year_label",borrow_count:1}}
]);
show("A7","借阅次数最多5位读者","borrow_archive",[
  {$group:{_id:"$reader_card",borrow_count:{$sum:1}}},
  {$sort:{borrow_count:-1,_id:1}},{$limit:5}
]);
show("A8","学院借阅量排行榜（lookup）","borrow_archive",[
  {$lookup:{from:"readers",localField:"reader_card",
            foreignField:"card_no",as:"reader"}},
  {$unwind:"$reader"},
  {$group:{_id:"$reader.college",borrow_count:{$sum:1}}},
  {$sort:{borrow_count:-1,_id:1}}
]);
print("\nA9 $merge：将A1分类统计落到 category_stats");
d.books.aggregate([...A1,{$merge:{
  into:"category_stats",on:"_id",
  whenMatched:"replace",whenNotMatched:"insert"
}}]).toArray();
print("category_stats 现有 " + d.category_stats.countDocuments({}) + " 组");
printjson(d.category_stats.find().sort({_id:1}).toArray());
