// 核验结构与计数（归档历史是66条，时间序列集合可能已因TTL变少）
const d=db.getSiblingDB("library");
print("服务版本: " + d.version());
d.getCollectionInfos().filter(x=>!x.name.startsWith("system.")).forEach(x=>
  print(x.name+" | "+x.type+" | "+JSON.stringify(x.options||{})));
["books","readers","borrow_archive","borrow_logs","category_stats","book_in_stock"]
  .forEach(n=>print(n+": "+d.getCollection(n).countDocuments({})+" 条"));
print("图书索引:");printjson(d.books.getIndexes());
print("样本逾期未还（按数据集中状态）：" +
  d.borrow_archive.countDocuments({status:"逾期",return_date:{$exists:false}}));
