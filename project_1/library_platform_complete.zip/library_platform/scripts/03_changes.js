// 任务三：U1-U4 / D1-D3，默认【仅预览】。先备份，再把开关改为 true。
// 仅用于实验副本；先做任务四统计，避免修改原始统计答案。
const d = db.getSiblingDB("library");
const RUN_MUTATIONS = false;
const RUN_TIMESERIES_DELETES = false; // 额外保护：仅适用于支持非 metaField 删除的服务器版本
function log(title, f) { print("\n" + title); printjson(f()); }
print("当前操作模式：" + (RUN_MUTATIONS ? "执行修改" : "仅预览，不写入"));
print("U1 目标书："); printjson(d.books.findOne({isbn:"9787115428028"}));
print("U2 目标类别（外语）文档数量：" + d.books.countDocuments({category:"外语"}));
print("U3 目标书："); printjson(d.books.findOne({isbn:"9787115428028"}));
print("U4 目标书："); printjson(d.books.findOne({isbn:"9787115293800"}));
print("D1 时间序列中已归还记录当前数量：" +
      d.borrow_logs.countDocuments({status:{$eq:"已归还"}}));
const overduePending={status:"逾期",return_date:{$exists:false}};
print("D2 删除前预览（仅清理逾期未还；原始数据可能为0）：");
printjson(d.borrow_logs.find(overduePending).toArray());
print("D3 目标读者：");
printjson(d.readers.findOne({card_no:"R20240016"}));
if (RUN_MUTATIONS) {
  log("U1 updateOne $inc：库存-5",()=>
    d.books.updateOne({isbn:"9787115428028",stock:{$gte:5}},{$inc:{stock:-5}}));
  log("U2 updateMany $mul：外语图书价格九折",()=>
    d.books.updateMany({category:"外语"},{$mul:{price:0.9}}));
  log("U3 $currentDate：新增当前更新时间",()=>
    d.books.updateOne({isbn:"9787115428028"},{$currentDate:{updated_at:true}}));
  log("U4 $unset：去掉tags",()=>
    d.books.updateOne({isbn:"9787115293800"},{$unset:{tags:""}}));
  const old=d.readers.findOne({card_no:"R20240016"});
  if (old) {
    // 保留 _id，整体替换其他字段
    const replacement={
      _id:old._id,card_no:old.card_no,name:old.name,college:old.college,
      email:old.email??null,phone:"15300153099",level:old.level,
      register_date:old.register_date,fav_categories:old.fav_categories??[]
    };
    log("D3 replaceOne：完整替换读者且保留_id",()=>
      d.readers.replaceOne({_id:old._id},replacement));
  }
  if (RUN_TIMESERIES_DELETES) {
    const version=d.version().split(".").map(Number);
    if (version[0]>=7) {
      log("D1 deleteOne：删除1条已归还时间序列记录",()=>
        d.borrow_logs.deleteOne({status:{$eq:"已归还"}}));
      print("D2 预览数：" + d.borrow_logs.countDocuments(overduePending));
      log("D2 deleteMany：逾期且无归还时间",()=>
        d.borrow_logs.deleteMany(overduePending));
    } else {
      print("当前版本低于7.0，跳过对时间序列的非metaField删除。");
    }
  } else print("D1/D2 跳过：请明确启用 RUN_TIMESERIES_DELETES；这是实际数据删除操作。");
}
print("脚本完成。注意：删除时间序列记录不会同步删除 borrow_archive 的历史归档。");
