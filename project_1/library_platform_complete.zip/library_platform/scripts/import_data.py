"""读取配套 JSON 数组/Extended JSON；不修改原始数据。
必须先执行 scripts/01_setup.js；从项目根目录运行：
    python scripts/import_data.py
"""
from pathlib import Path
from bson import json_util
from pymongo.errors import PyMongoError
import sys

PROJECT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT))
from mongodb_connect import connect

def load(name):
    path = PROJECT / "data" / (name + ".txt")
    rows = json_util.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(rows, list) or not rows:
        raise ValueError(str(path) + " 必须是非空JSON数组")
    return rows

def main():
    client, db = connect()
    try:
        info = {x["name"]: x for x in db.list_collections()}
        if (info.get("borrow_logs", {}).get("type") != "timeseries"
                or not info.get("book_logs", {}).get("options", {}).get("capped")):
            raise RuntimeError("请先运行 scripts/01_setup.js 创建特殊集合")
        names = ("books", "readers", "borrow_logs", "borrow_archive")
        nonempty = [n for n in names if db[n].estimated_document_count() > 0]
        if nonempty:
            raise RuntimeError("检测到已有数据，已停止导入以避免重复：" + ", ".join(nonempty) +
                               "；如需重做，请备份后在实验库手动清空/重建")
        books, readers, logs = load("books"), load("readers"), load("borrow_logs")
        # 先验证引用关系与主键，确保样本记录不丢失
        isbn = [x["isbn"] for x in books]
        cards = [x["card_no"] for x in readers]
        if len(set(isbn)) != len(isbn) or len(set(cards)) != len(cards):
            raise ValueError("books.isbn 或 readers.card_no 存在重复")
        wrong = [x for x in logs if x["book_isbn"] not in isbn
                 or x["reader_card"] not in cards]
        if wrong:
            raise ValueError(f"存在 {len(wrong)} 条关联不到图书或读者的借阅记录")
        # 根据任务书先用 insert_one 插入一本，再用 insert_many 插入其他图书
        db.books.insert_one(dict(books[0]))
        if len(books) > 1:
            db.books.insert_many([dict(x) for x in books[1:]])
        db.readers.insert_many([dict(x) for x in readers])
        db.borrow_archive.insert_many([dict(x) for x in logs])
        # 向时间序列集合写入原始数据快照；TTL 随后可能自动删除旧记录
        db.borrow_logs.insert_many([dict(x) for x in logs])
        print("导入成功：books", db.books.count_documents({}),
              "readers", db.readers.count_documents({}),
              "borrow_archive", db.borrow_archive.count_documents({}),
              "borrow_logs（当前）", db.borrow_logs.count_documents({}))
        print("提醒：borrow_logs 因2年 TTL 后续可能少于66条；统计请使用 borrow_archive。")
    finally:
        client.close()

if __name__ == "__main__":
    main()
