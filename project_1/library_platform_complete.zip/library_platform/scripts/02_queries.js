// Q1～Q16：要求的全部查询。请在修改/删除数据前运行以获得原始数据集计数。
const d = db.getSiblingDB("library");
function run(id, name, coll, filter, projection) {
  const c = d.getCollection(coll);
  print("\n" + id + " " + name + "；匹配 " + c.countDocuments(filter) + " 条");
  printjson(c.find(filter, projection || {}).limit(20).toArray());
}
run("Q1","定价高于80", "books", {price: {$gt:80}});
run("Q2","库存低于10", "books", {stock: {$lt:10}});
run("Q3","ISBN精确匹配", "books", {isbn: {$eq:"9787115428028"}});
run("Q4","邮箱为空（也可匹配缺失字段）", "readers", {email: {$eq:null}});
run("Q5","排除人民邮电出版社", "books", {publisher: {$ne:"人民邮电出版社"}});
run("Q6","计算机或经济管理", "books", {category: {$in:["计算机","经济管理"]}});
run("Q7","计算机且评分高于4", "books",
    {$and:[{rating:{$gt:4.0}}, {category:"计算机"}]});
run("Q8","评分低于3.5或库存为0", "books",
    {$or:[{rating:{$lt:3.5}}, {stock:0}]});
run("Q9","书名含Python", "books", {title:{$regex:"Python",$options:"i"}});
run("Q10","同时含编程与入门", "books", {tags:{$all:["编程","入门"]}});
run("Q11","恰好3个标签", "books", {tags:{$size:3}});
run("Q12","存在tags字段", "books", {tags:{$exists:true}});
run("Q13","_id为字符串", "books", {_id:{$type:"string"}});
print("\nQ14 评分降序前5条:");
printjson(d.books.find().sort({rating:-1}).limit(5).toArray());
print("\nQ15 仅返回书名、价格、评分，无_id；合计：" + d.books.countDocuments({}));
printjson(d.books.find({}, {_id:0,title:1,price:1,rating:1}).toArray());
const cats=d.books.distinct("category");
print("\nQ16 类别清单，种类数：" + cats.length);
printjson(cats);
