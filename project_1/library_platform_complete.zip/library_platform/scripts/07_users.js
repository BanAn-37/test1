// 任务四 S1-S2。用具有 createUser 权限的账号运行，密码安全交互输入。
// 注意：无认证环境建议先在 admin 数据库建立管理员账户，再启用 authorization。
const d=db.getSiblingDB("library");
for(const [name,roles] of [
  ["libReader",[{role:"read",db:"library"}]],
  ["libWriter",[{role:"readWrite",db:"library"},{role:"dbAdmin",db:"library"}]]
]){
  if(d.getUser(name)){print(name+" 已存在，跳过");continue;}
  print("请输入账户 "+name+" 的密码：");
  d.createUser({user:name,pwd:passwordPrompt(),roles:roles});
  print("成功创建 "+name);
}
print("账户已创建；授权规则需在启用 MongoDB 访问控制后验证。");
