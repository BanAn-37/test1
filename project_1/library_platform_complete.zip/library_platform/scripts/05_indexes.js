// I1～I5：五个索引及重复 ISBN 和执行计划实验。
const d=db.getSiblingDB("library");
print("I1 isbn 唯一索引: " + d.books.createIndex({isbn:1},{unique:true,name:"uniq_isbn"}));
print("I2 title 单键索引: " + d.books.createIndex({title:1},{name:"idx_title"}));
print("I3 category 单键索引: " + d.books.createIndex({category:1},{name:"idx_category"}));
print("I4 tags 多键索引: " + d.books.createIndex({tags:1},{name:"idx_tags"}));
print("I5 category+price 复合索引: " + d.books.createIndex(
  {category:1,price:1},{name:"idx_category_price"}));
print("\n索引清单:"); printjson(d.books.getIndexes());
print("\n唯一索引验证（预期写入失败）:");
try {
  d.books.insertOne({isbn:"9787115428028",title:"重复ISBN校验"});
  throw new Error("意外：没有触发唯一键冲突");
} catch(e) {
  if (e.code===11000) print("验证成功：E11000 重复ISBN已被拒绝");
  else throw e;
}
const query={category:"计算机",price:{$gt:80}};
function profile(name,hint) {
  const exp=d.books.find(query).hint(hint).explain("executionStats");
  print(name + " - totalKeysExamined=" + exp.executionStats.totalKeysExamined +
    ", totalDocsExamined=" + exp.executionStats.totalDocsExamined +
    ", executionTimeMillis=" + exp.executionStats.executionTimeMillis);
  printjson(exp.queryPlanner.winningPlan);
}
profile("不使用索引（$natural强制集合扫描）",{$natural:1});
profile("指定复合索引", "idx_category_price");
print("注意：只有20条记录，毫秒耗时通常不足以证明性能差异；结合扫描文档数量观察。");
