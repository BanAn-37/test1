// 任务二：建立四个业务集合、固定集合、视图和历史保护归档集合。
// 在项目根目录运行 mongosh "mongodb://127.0.0.1:27017" --file scripts/01_setup.js
const d = db.getSiblingDB("library");
function ensureNormal(name) {
  const old = d.getCollectionInfos({name: name})[0];
  if (!old) { d.createCollection(name); print("创建普通集合: " + name); }
  else if (old.type !== "collection") throw new Error(name + " 不是普通集合");
}
["books", "readers", "category_stats", "borrow_archive"].forEach(ensureNormal);

const tsl = d.getCollectionInfos({name:"borrow_logs"})[0];
if (!tsl) {
  d.createCollection("borrow_logs", {
    timeseries: {timeField: "borrow_date", granularity: "hours"},
    expireAfterSeconds: 63072000
  });
  print("创建时间序列集合 borrow_logs");
} else if (tsl.type !== "timeseries") {
  throw new Error("已有 borrow_logs 不是时间序列集合；请备份后手动处理，脚本不会删除旧数据");
} else {
  print("borrow_logs 已存在，请检查 timeField/granularity/expireAfterSeconds 与任务书是否一致");
}
const cap = d.getCollectionInfos({name:"book_logs"})[0];
if (!cap) {
  d.createCollection("book_logs", {capped: true, size: 1048576, max: 1000});
} else if (!cap.options || !cap.options.capped) {
  throw new Error("已有 book_logs 不是固定集合");
}
const v = d.getCollectionInfos({name:"book_in_stock"})[0];
if (!v) {
  d.createView("book_in_stock", "books", [{$match: {stock: {$gt:0}}}]);
} else if (v.type !== "view") {
  throw new Error("已有 book_in_stock 不是视图");
}
print("\n集合类型/参数:");
d.getCollectionInfos().filter(x => !x.name.startsWith("system.")).forEach(x => {
  print(x.name + ": " + x.type + " " + JSON.stringify(x.options || {}));
});
print("\n建库完成。注意：历史借阅超过2年会被时间序列 TTL 清理；borrow_archive 用于保留66条原始记录。");
